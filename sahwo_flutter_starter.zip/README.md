# Sahwo

Sahwo — Wake up and start your day right.

## Current starter features
- Arabic right-to-left interface
- Home dashboard and demo points
- Daily wake-up check-in
- Demo community feed
- Habit challenges
- Profile placeholder

## Important limitations
This is an early UI prototype. Points and check-ins are stored only in app memory and reset when the app restarts. There is no authentication, cloud database, real user community, prayer-time calculation, or alarm notification yet.

## Run locally
1. Install Flutter and Android Studio on a computer.
2. Unzip this project.
3. In the project folder run:
   - `flutter pub get`
   - `flutter run`

## GitHub
Upload the project files and folders to the `sahwo` repository. Do not upload build output folders such as `build/` or `.dart_tool/`.
